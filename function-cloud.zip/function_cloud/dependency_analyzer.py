"""
Dependency analyzer for the Function Cloud (FC) library.
"""

import inspect
import ast
import json
from typing import Callable, Set, Dict, Any

from function_cloud.config import FCConfig

# Optional import for Groq LLM integration
try:
    import groq
    HAS_GROQ = True
except ImportError:
    HAS_GROQ = False


class DependencyAnalyzer:
    """Analyzes function dependencies using static analysis and LLM."""
    
    @staticmethod
    def analyze_imports(func: Callable) -> Set[str]:
        """
        Extract import statements from function source code.
        
        Args:
            func (Callable): The function to analyze.
            
        Returns:
            Set[str]: Set of imported module names.
        """
        source = inspect.getsource(func)
        parsed = ast.parse(source)
        imports = set()
        
        for node in ast.walk(parsed):
            if isinstance(node, ast.Import):
                for name in node.names:
                    imports.add(name.name.split('.')[0])
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    imports.add(node.module.split('.')[0])
        
        return imports
    
    @staticmethod
    def enhance_with_llm(func: Callable, imports: Set[str]) -> Dict[str, Any]:
        """
        Use Groq LLM to enhance dependency detection and generate requirements.
        
        Args:
            func (Callable): The function to analyze.
            imports (Set[str]): Set of imported module names.
            
        Returns:
            Dict[str, Any]: Dictionary with dependency information.
        """
        if not FCConfig.llm_enabled:
            return {"packages": list(imports)}
            
        source = inspect.getsource(func)
        func_name = func.__name__
        module_name = func.__module__
        
        if not FCConfig.llm_api_key:
            return {"packages": list(imports)}
        
        # Use Groq for dependency analysis
        if FCConfig.llm_provider == "groq" and HAS_GROQ:
            client = groq.Client(api_key=FCConfig.llm_api_key)
            
            prompt = f"""
            I have a Python function that I want to deploy to the cloud.
            Please analyze its dependencies and generate a requirements.txt file.
            
            Function name: {func_name}
            Module: {module_name}
            Identified imports: {', '.join(imports)}
            
            Function source:
            ```python
            {source}
            ```
            
            Generate a JSON response with these fields:
            1. "packages": List of required pip packages with versions
            2. "system_dependencies": List of system packages needed
            3. "python_version": Recommended Python version
            """
            
            try:
                response = client.chat.completions.create(
                    model="llama3-70b-8192",  # Using Llama 3 70B model
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=500
                )
                result_text = response.choices[0].message.content
                # Extract JSON from the response
                json_start = result_text.find('{')
                json_end = result_text.rfind('}') + 1
                if json_start >= 0 and json_end > json_start:
                    json_str = result_text[json_start:json_end]
                    result = json.loads(json_str)
                    return result
                else:
                    return {"packages": list(imports)}
            except Exception as e:
                print(f"LLM analysis failed: {e}")
                return {"packages": list(imports)}
        else:
            # Fallback to basic dependency analysis
            return {"packages": list(imports)}
