"""
URL manager for the Function Cloud (FC) library.
"""

import inspect
import hashlib
from typing import Callable

from function_cloud.config import FCConfig


class FCURLManager:
    """Manages function URLs."""
    
    @staticmethod
    def generate_url_path(func: Callable) -> str:
        """
        Generate a unique URL path for a function.
        
        Args:
            func (Callable): The function to generate a URL path for.
            
        Returns:
            str: The URL path.
        """
        module = func.__module__
        name = func.__name__
        source = inspect.getsource(func)
        source_hash = hashlib.md5(source.encode()).hexdigest()[:8]
        return f"{module}.{name}-{source_hash}"
    
    @staticmethod
    def function_to_endpoint(func_path: str) -> str:
        """
        Convert a function path to a Modal endpoint URL.
        
        Args:
            func_path (str): The function path.
            
        Returns:
            str: The Modal endpoint URL.
        """
        base_url = f"https://{FCConfig.stub_name}--{func_path.replace('.', '-')}.modal.run"
        return base_url
